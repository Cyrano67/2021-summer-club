package com.cestc.vspace;

import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VspaceWebApplication {

	public static void main(String[] args) {
		
	}

}
