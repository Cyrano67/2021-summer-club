package com.cestc.vspace;/*
  author:wyj
  createDate:$(Dare) $(TIME)
*/

import com.cestc.vspace.pojo.Cart;
import com.cestc.vspace.pojo.ShippingInfo;
import com.cestc.vspace.service.shippinginfoService;
import org.apache.dubbo.config.annotation.Reference;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

@SpringBootTest(classes ={ShippingInfoServiceApplication.class})
@RunWith(SpringRunner.class)
public class ShippingServiceTest{

    public ShippingServiceTest() {
        // TODO Auto-generated constructor stub
    }
    @Reference
    private shippinginfoService shippinginfoservice;

    @Test
    public void test() {
//        ShippingInfo shp=new ShippingInfo(5,"1","2","3","4","5","6","7");
//        System.out.println(shippinginfoservice.register(shp));
//        shippinginfoservice.delete(1);
//        shippinginfoservice.delete(5);
    }
}