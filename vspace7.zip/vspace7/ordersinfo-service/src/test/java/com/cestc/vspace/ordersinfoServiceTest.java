package com.cestc.vspace;

import org.apache.dubbo.config.annotation.Reference;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;
import com.cestc.vspace.pojo.Clothes;
import com.cestc.vspace.pojo.OrdersInfo;
import java.util.List;
import com.cestc.vspace.service.ordersinfoService;

@org.springframework.boot.test.context.SpringBootTest(classes ={OrdersInfoServiceApplication.class})
@org.junit.runner.RunWith(org.springframework.test.context.junit4.SpringRunner.class)
public class ordersinfoServiceTest {

	public ordersinfoServiceTest() {
		// TODO Auto-generated constructor stub
	}
	@org.apache.dubbo.config.annotation.Reference
	private ordersinfoService ordersinfoservice;
	
	@org.junit.Test
	public void test() {
/*
		List<OrdersInfo> list;
		list=ordersinfoservice.();
		for (int i = 0; i < list.size(); i++) {
			System.out.println(list.get(i).getCname());
		}


 */
		List<OrdersInfo> list;
		list=new java.util.ArrayList<OrdersInfo>();
		OrdersInfo order;
		order=ordersinfoservice.findOrderByNum(4);
		order.setOid(8);
		order.setOrderNo(8);
		list.add(order);
		order.setOid(10);
		order.setOrderNo(10);
		list.add(order);
		System.out.println(ordersinfoservice.insertOrders(list));
	}

//	public static void main(String[] args) {
//		// TODO Auto-generated method stub
//
//	}

}
