package com.cestc.vspace;/*
  author:wyj
  createDate:$(Dare) $(TIME)
*/


import com.cestc.vspace.pojo.Cart;
import com.cestc.vspace.service.cartService;
import org.apache.dubbo.config.annotation.Reference;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.Iterator;
import java.util.List;

@SpringBootTest(classes ={CartServiceApplication.class})
@RunWith(SpringRunner.class)
public class CartServiceTest {

    public CartServiceTest() {
        // TODO Auto-generated constructor stub
    }
    @Reference
    private cartService cartservice;

    @Test
    public void test() {
//        if(cartservice.findbyCD(2,3)!=null){
//
//            Cart cc=cartservice.findbyCD(2,3);
//            System.out.println(cartservice.updateOfquality(cc,100));
//        }
//        cartservice.delete(1);
//        cartservice.delete(7);
//        cartservice.delete(10);
//        cartservice.delete(15);
//        cartservice.delete(17);
//        cartservice.delete(104);
        List<Cart> carts=cartservice.find_of_usre(3);
        Iterator<Cart> iter = carts.iterator();
        while(iter.hasNext()){
            System.out.println(iter.next().getCaid());
        }
    }
}
